module.exports = function(res){
	res.statusCode = 404;
	res.end();
}